﻿Partial Class melodiasDataSet
    Partial Public Class usuarioDataTable

    End Class

    Partial Public Class clienteDataTable

    End Class
End Class

Namespace melodiasDataSetTableAdapters

End Namespace
