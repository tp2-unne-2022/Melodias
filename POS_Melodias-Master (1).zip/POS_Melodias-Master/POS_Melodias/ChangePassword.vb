﻿Public Class ChangePassword


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnCambiarContraseña.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles BtnVolver.Click
        Me.Close()
    End Sub

End Class